-- CREATE TABLE IF NOT EXISTS `tasks` (
--     `ID` INTEGER PRIMARY KEY AUTOINCREMENT,
--     `Uzdevuma_teksts` TEXT NOT NULL,
--     `Ir_izpildits` BOOLEAN DEFAULT 0.00,
--     `Laika_zimogs` DATETIME DEFAULT CURRENT_TIMESTAMP
--     );

-- INSERT INTO `tasks`(`Uzdevuma_teksts`)
-- VALUES 
-- ('Izdari flipu3');

DELETE FROM tasks WHERE ID = 2