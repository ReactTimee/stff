const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const sqlite3 = require("sqlite3");
const app = express();
app.use(bodyParser.json());
app.use(cors());

const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

const db = new sqlite3.Database("database.db");

db.run(`
          CREATE TABLE IF NOT EXISTS "tasks" (
      "ID" INTEGER PRIMARY KEY AUTOINCREMENT,
      "Uzdevuma_teksts" TEXT NOT NULL,
      "Ir_izpildits" BOOLEAN DEFAULT 0.00,
      "Laika_zimogs" DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

console.log("Database setup completed.");

app.get("/tasks", function (req, res) {
  db.all("SELECT * FROM `tasks`;", function (err, rows) {
    if (err) {
      return res.status(500).json(err);
    } else {
      console.log(rows);
      return res.status(200).json(rows);
    }
  });
});

app.post("/add-task", function (req, res) {
  const taskText = req.body.taskText;
  db.run(
    'INSERT INTO "tasks" (Uzdevuma_teksts) VALUES(?)',
    [taskText],
    function (err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      return res.status(200).json({ message: "Task added successfully" });
    }
  );
});

//app.post('/update-task', function(req, res) {
//   const taskObject = req.body.taskObject;
//    db.run(`UPDATE "tasks" SET Ir_izpildits = NOT Ir_izpildits WHERE ID = ?`, [taskObject.id], function(err) {
//    if (err) {
//       console.error(err.message);
//       return res.status(500).json({ error: err.message });
//  }
//  return res.status(200).json({ message: "Task updated successfully", changes: this.changes });
//   });
//});

app.put("/update-task", function (req, res) {
  console.log("update", req.body);
  const taskId = req.body.taskObject.Id;
  const newDoneValue = req.body.taskObject.done;
  db.run(
    `UPDATE "tasks" SET Ir_izpildits = ? WHERE ID = ?`,
    newDoneValue,
    taskId,
    function (err) {
      if (err) {
        console.error(err.message);
        return res.status(500).json({ error: err.message });
      }
      return res
        .status(200)
        .json({ message: "Task updated successfully", changes: this.changes });
    }
  );
});

app.delete("/delete-task", function (req, res) {
  console.log("delete", req.body);
  const taskId = req.body.taskObject.id;
  console.log("delete task id", taskId);

  db.run(`DELETE FROM tasks WHERE ID = ?`, taskId, function (err) {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: err.message });
    } else {
      console.log("delete success");
      return res.status(200).json({ message: "Task deleted successfully" });
    }
  });
});
