// Class for a task
class Task {
  id;
  taskText;
  done;
  timestamp;

  constructor(padotaisID, padotaisTeksts, padotaisDone, padotaisTs) {
    this.id = padotaisID;
    this.taskText = padotaisTeksts;
    this.done = padotaisDone;
    this.timestamp = padotaisTs;
  }
}

//SERVER SETUP
const localHost = "http://localhost:5000";
const getAllTasksEndpoint = "/tasks";
const addTaskEndpoint = "/add-task";
const updateTaskEndpoint = "/update-task";
const deleteTaskEndpoint = "/delete-task";

//CLIENT SETUP
const enterButton = document.getElementById("enter");
enterButton.addEventListener("click", addTaskFromInput);
const input = document.getElementById("userInput");
input.addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
    addTaskFromInput();
  }
});
const ul = document.querySelector("ul");

//get all tasks on load of page and display them
async function getAllTasks() {
  //clear list
  ul.innerHTML = "";
  const response = await fetch(localHost + getAllTasksEndpoint);
  const tasks = await response.json();

  console.log("tasks", tasks);

  tasks.forEach((task) => {
    const taskObject = new Task(
      task.ID,
      task.Uzdevuma_teksts,
      task.Ir_izpildits,
      task.Laika_zimogs
    );
    createListElement(taskObject);
  });
}
//run on load
getAllTasks();

async function addTaskFromInput() {
  if (input.value.length > 0) {
    await addTaskToDatabase(input.value);
  }
}

async function addTaskToDatabase(task) {
  console.log("add task to db", task);
  const response = await fetch(localHost + addTaskEndpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ taskText: task }),
  });
  const data = await response.json();
  console.log(data);
  getAllTasks();
}

function createListElement(taskObject) {
  let task = taskObject.taskText;
  var li = document.createElement("li"); // creates an element "li"
  li.appendChild(document.createTextNode(task)); //makes text from input field the li text
  li.classList.add(
    "list-group-item",
    "d-flex",
    "justify-content-between",
    "align-items-start"
  );
  ul.appendChild(li); //adds li to ul
  input.value = ""; //Reset text input field

  //START STRIKETHROUGH
  //check if task is done
  if (taskObject.done === 1) {
    li.classList.add("done");
  }

  //function to cross out list items if clicked on
  function crossOut() {
    console.log("crossOut", taskObject.id, taskObject.done);
    if (taskObject.done === 0) {
      li.classList.add("done");
      taskObject.done = 1;
    } else {
      li.classList.remove("done");
      taskObject.done = 0;
    }

    //update database
    updateTask(taskObject);
  }
  li.addEventListener("click", crossOut);
  //END STRIKETHROUGH

  // START ADD DELETE BUTTON
  var dBtn = document.createElement("button");
  dBtn.appendChild(document.createTextNode("X"));
  dBtn.classList.add("btn", "btn-secondary", "btn-sm");
  li.appendChild(dBtn);
  dBtn.addEventListener("click", deleteListItem);
  // END ADD DELETE BUTTON

  function deleteListItem() {
    console.log("deleteListItem", taskObject.id);
    //delete from database
    deleteTask(taskObject);
    //remove from DOM
    li.classList.add("delete");
  }
  //END ADD CLASS DELETE
}

async function updateTask(taskObject) {
  const response = await fetch(localHost + updateTaskEndpoint, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ taskObject: taskObject }),
  });
  const data = await response.json();
  console.log(data);
}

async function deleteTask(taskObject) {
  console.log("delete from db", taskObject);
  const response = await fetch(localHost + deleteTaskEndpoint, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ taskObject: taskObject }),
  });
  const data = await response.json();
  console.log("browser db delete", data);
}
//  async function updateTask(taskObject) {
// const response = await fetch(localHost + updateTaskEndpoint, {
//   method: 'POST',
// headers: {
//  'Content-Type': 'application/json'
// },
// body: JSON.stringify({taskObject: taskObject })
// });
// const data = await response.json();
// console.log(data);
// getAllTasks();
//}
