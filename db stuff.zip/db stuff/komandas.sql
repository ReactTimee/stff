UPDATE Lasitajs
SET epasts = 'Peteris22@inbox.lv'
WHERE vards='Peters';

SELECT *
FROM `Lasitajs`;

DELETE FROM Lasitajs
WHERE id = '7';

DELETE from Registrs
WHERE Lasitaja_id = '7';

INSERT into Gramatas(nosaukums,autors)
VALUES  ('gramata1','janitis'),
('gramata2','janitis2'),
('gramata13','janitis3');

SELECT * from Registrs;

SELECT * from Lasitajs;

SELECT * from Gramatas;