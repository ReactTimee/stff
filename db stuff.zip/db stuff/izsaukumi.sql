--SELECT * 
--FROM Registrs
--WHERE Lasitaja_id = 5;
--SELECT * 
--FROM Registrs
--WHERE Gramatas_id = 1;


SELECT 
`Lasitajs`.`vards` AS `Lasitajs`,
`Lasitajs`.`epasts` AS `Epasts`,
`Gramatas`.`autors` AS `Autors`,
`Gramatas`.`nosaukums` AS `Gramatas nosaukums`,
`Registrs`.`diena_iznem` AS `Izņemšanas diena`,
`Registrs`.`diena_nodot` AS `Atdošanas diena`,
`Registrs`.`Soda_nauda` AS `Soda Nauda`
FROM `Registrs`
JOIN `Lasitajs`
ON `Lasitajs`.`id` = `Registrs`.`Lasitaja_id`
JOIN `Gramatas`
ON `Gramatas`.`id` = `Registrs`.`Gramatas_id`
WHERE `Lasitaja_id` = 7;





SELECT 
`Gramatas`.`autors` AS `Autors`,
`Gramatas`.`nosaukums` AS `Gramatas nosaukums`,
`Lasitajs`.`vards` AS `Lasitajs`,
`Lasitajs`.`epasts` AS `Epasts`,
`Registrs`.`diena_iznem` AS `Izņemšanas diena`,
`Registrs`.`diena_nodot` AS `Atdošanas diena`,
`Registrs`.`Soda_nauda` AS `Soda Nauda`
FROM `Registrs`
JOIN `Lasitajs`
ON `Lasitajs`.`id` = `Registrs`.`Lasitaja_id`
JOIN `Gramatas`
ON `Gramatas`.`id` = `Registrs`.`Gramatas_id`
WHERE `Gramatas_id` = 7;