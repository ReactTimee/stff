CREATE TABLE IF NOT EXISTS Gramatas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nosaukums text not NULL,
    autors text not NULL
    );


