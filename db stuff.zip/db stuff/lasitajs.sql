CREATE TABLE IF NOT EXISTS Lasitajs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards text not NULL,
    epasts text not NULL,
    ir_aktivs BOOLEAN DEFAULT "false" not NULL
    );

INSERT INTO Lasitajs(vards,epasts)
VALUES ('L','nmvbcx@gmail.com');