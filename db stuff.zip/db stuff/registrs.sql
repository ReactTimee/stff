CREATE TABLE IF NOT EXISTS Registrs (
    id  INTEGER PRIMARY KEY AUTOINCREMENT,
    diena_iznem DATE not NULL, 
    diena_nodot Date not NULL,
    Lasitaja_id INTEGER not NULL,
    Gramatas_id INTEGER not NULL,
   --FOREIGN KEY (Lasitaja_id) REFERENCES Lasitajs(id),
   -- FOREIGN KEY (Gramatas_id) REFERENCES Gramatas(id),
    Soda_nauda  REAL DEFAULT 0.00
  );

INSERT INTO Registrs(diena_iznem,diena_nodot,Gramatas_id,Lasitaja_id)
VALUES ('2024-01-19','2024-01-29',1,6),
('2024-01-19','2024-01-29',7,5),
('2024-01-19','2024-01-29',1,6),
('2024-01-19','2024-01-29',7,7),
('2024-01-19','2024-01-29',1,7);

